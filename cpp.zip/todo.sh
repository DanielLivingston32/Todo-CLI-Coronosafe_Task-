#!/usr/bin/env bash

./todo.out "$@"
